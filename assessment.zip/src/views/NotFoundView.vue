<template>
  <div class="flex flex-col justify-center items-center">
    <h1>404 route not found</h1>
    <p> Return to <router-link class="text-blue-500" :to="{ path: '/'}">HOME</router-link></p>
  </div>
</template>
