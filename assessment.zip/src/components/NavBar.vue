<template>
  <nav class="relative px-4 py-4 flex justify-center items-center bg-white">
    <router-link :to="{ path: '/' }" class="text-3xl font-bold leading-none">
      SCHEDULING
    </router-link>
  </nav>
</template>

<script setup></script>
